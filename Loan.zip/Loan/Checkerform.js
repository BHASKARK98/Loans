import React from 'react';
import Doc from './Doc';
import TextField from '@material-ui/core/TextField';


class Checkerform extends React.Component
{
    
    state=
    {
        name:' ',
        nameError:' ',
        mobile:' ',
        mobileError:' ',
        aadhar:' ',
        mail:' ',
        nominee:' ',
        nomineeMobile:' ',
        emergencycontact:' ',
        emergencymobile:' ',
        nomineeAadhar:' '
        
    }

    nomineeAadharHandler(e)
    {
        
        const nomineeAadhar=e.target.value;
       // const pattern="^[a-zA-Z]+$";
        const pattern="^[1-9]{1}[0-9]{11}$";
       // const pattern="^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$";
        this.setState({nomineeAadhar:nomineeAadhar});
        if(nomineeAadhar.match(pattern))
        {
            this.setState({nomineeAadhar:" "})
    
        }
        else{
            this.setState({nomineeAadhar:"Aadhar number should be of length 12"});
        }
    }

    
nomineeHandler(e)
{
    
    const nominee=e.target.value;
    const pattern="^[a-zA-Z]+$";
    this.setState({nominee:nominee});
    if(nominee.match(pattern))
    {
        this.setState({nominee:" "})

    }
    else{
        this.setState({nominee:"only alphabets"});
    }
}

nameHandler(e)
{
    
    const name=e.target.value;
    const pattern="^[a-zA-Z]+$";
    this.setState({name:name});
    if(name.match(pattern))
    {
        this.setState({name:" "})

    }
    else{
        this.setState({name:"only alphabets"});
    }
}

emergencyNameHandler(e)
{
    
    const emergencycontact=e.target.value;
    const pattern="^[a-zA-Z]+$";
    this.setState({emergencycontact:emergencycontact});
    if(emergencycontact.match(pattern))
    {
        this.setState({emergencycontact:" "})

    }
    else{
        this.setState({emergencycontact:"only alphabets"});
    }
}


nomineemobileHandler(e)
{
    
    const nomineeMobile=e.target.value;
   // const pattern="^[a-zA-Z]+$";
    const pattern="^[6-9]{1}[0-9]{9}$";
    this.setState({nomineeMobile:nomineeMobile});
    if(nomineeMobile.match(pattern))
    {
        this.setState({nomineeMobile:" "})

    }
    else{
        this.setState({nomineeMobile:"only Numbers with length of 10"});
    }
}

emergencyMobileHandler(e)
{
    
    const emergencymobile=e.target.value;
   // const pattern="^[a-zA-Z]+$";
    const pattern="^[6-9]{1}[0-9]{9}$";
    this.setState({emergencymobile:emergencymobile});
    if(emergencymobile.match(pattern))
    {
        this.setState({emergencymobile:" "})

    }
    else{
        this.setState({emergencymobile:"only Numbers with length of 10"});
    }
}
mobileHandler(e)
{
    
    const mobile=e.target.value;
   // const pattern="^[a-zA-Z]+$";
    const pattern="^[6-9]{1}[0-9]{9}$";
    this.setState({mobile:mobile});
    if(mobile.match(pattern))
    {
        this.setState({mobile:" "})

    }
    else{
        this.setState({mobile:"only Numbers with length of 10"});
    }
}
mailHandler(e)
{
    
    const mail=e.target.value;
   // const pattern="^[a-zA-Z]+$";
    //const pattern="[6-9]{1}[0-9]{9}";
    const pattern="^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$";
    this.setState({mail:mail});
    if(mail.match(pattern))
    {
        this.setState({mail:" "})

    }
    else{
        this.setState({mail:"Should contain @ and com/in"});
    }
}

aadharHandler(e)
{
    
    const aadhar=e.target.value;
   // const pattern="^[a-zA-Z]+$";
    const pattern="^[1-9]{1}[0-9]{11}$";
   // const pattern="^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$";
    this.setState({aadhar:aadhar});
    if(aadhar.match(pattern))
    {
        this.setState({aadhar:" "})

    }
    else{
        this.setState({aadhar:"Aadhar number should be of length 12"});
    }
}
render(){
    return(
  <form style={{backgroundColor:"white",lineHeight:"62px"}}>
        <div  className="form-horizontal" className="container-fluid">
            <div>

             <div className="form-group" className="row" >
                <div className="col-sm-6" >
                <TextField label="Name"  className="form-control"  onChange={(e)=>this.nameHandler(e)}/>
                    <Doc name1={this.state.name}/>
                </div>
                    <div className="col-sm-6">
                    <TextField label="Date of Birth"  className="col-sm-4" type="date" className="form-control"/>
                    </div>
             </div >

              {/* <div className="form-group" className="row">
                    <div className="col-sm-6">
                    <TextField label="Aadhar Number" className="form-control" onChange={(e)=>this.aadharHandler(e)}/>
                    <Doc aadhar1={this.state.aadhar}/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="PAN Card Number"   className="form-control"/>
                    </div>
                   
                    </div>    */}
               
                 <div className="form-group" className="row">
                    <div className="col-sm-6">
                        <TextField label="Mobile Number"   className="form-control" onChange={(e)=>this.mobileHandler(e)}/>
                        <Doc mobile1={this.state.mobile}/>
                    </div>
                    <div className="col-sm-6">
                        <TextField label="Email Id"  className="form-control" onChange={(e)=>this.mailHandler(e)}/>
                        <Doc mail1={this.state.mail}/>
                    </div>
                   
                    </div>

                    <div className="form-group" className="row">
                    <div className="col-sm-6">
                    <TextField label="Account Number"   className="form-control"/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="Annual Income"   className="form-control"/>
                    </div>
                    </div>                    

                    <div className="form-group" className="row">
                    <div className="col-sm-6">
                    <TextField label="Amount of loan required"   className="form-control"/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="Purpose of Loan"   className="form-control"/>
                    </div>
                    </div>
                    <div className="form-group" className="row">
                    
                    <div className="col-sm-6" >
                    <TextField label="Profession"   className="form-control"/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="country"   className="form-control"/>
                    </div>
                    </div>

                    <div className="form-group" className="row">
                    <div className="col-sm-6">
                    <TextField label="Nominee's name"   className="form-control" onChange={(e)=>this.nomineeHandler(e)}/>
                    <Doc nominee1={this.state.nominee}/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="Nominee's Phone number"   className="form-control"onChange={(e)=>this.nomineeAadharHandler(e)}/>
                        <Doc nomineeAadhar1={this.state.nomineeAadhar}/> 
                    </div>
                    </div>

                    {/* <div className="form-group" className="row">
                    <div className="col-sm-6">
                    <TextField label="Nominee's mobile Number"   className="form-control" onChange={(e)=>this.nomineemobileHandler(e)}/>
                        <Doc nomineemobile1={this.state.nomineeMobile}/>
                    </div>
                    <div className="col-sm-6">
                    <TextField label="Nominee's Address"   className="form-control"/>
                    </div>
                    </div> */}

                   
                    

                     <div >
                     <button type="button" className="btn btn-primary" style={{width:170,marginTop:30,marginLeft:180,justifyContent:"Centre"}}>Submit
                            </button>
                    </div>

                 </div>

              
        </div>
    </form>



    );
    }
}
export default Checkerform;
