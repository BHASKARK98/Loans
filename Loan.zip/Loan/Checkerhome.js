import React from 'react';
import Dashboard from './Dashboard';
//import Nav from './Nav';
import Newnav from './Newnav';
import Checkerlog from './checkrlog';
class Checkerhome extends React.Component {
    
    render() {
        return (
            <div>
                <div>
                    <Checkerlog/>
                </div><br/><br/>
                <div className="row">
                    <div className="col-sm-2"> </div>
                    <div className="col-sm-8"> <Dashboard /></div>
                    <div className="col-sm-2"> </div>
                </div>
            </div>
        );
    }
}
export default Checkerhome;