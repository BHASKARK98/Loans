import React from 'react';
import './checker.css';
//import Checkerform from './Checkerform';
import Displayuser from './Displayuser';
//import Navops from './Navops';
import CheckerLog from './checkrlog';
//import "bootstrap/dist/css/bootstrap.min.css";
class Checkerpage extends React.Component
{
    state={
        fileUrl: this.props.match.params.aadhar
    }
   
    constructor(props){
        super(props);
        let str= this.props.match.params.aadhar;
        str=str.replace(/\\/g,"\\\\");
        console.log(str);
        this.state.fileUrl=str;
        let str1=str.substring(49);
        this.state.fileUrl=str1;
        console.log(str1);
    }
    
    render()
   {
       
    return (
        <div>
        <div>
        <CheckerLog/>
        </div><br/><br/>
         <div className="row">    
         <div className="col-sm-6">         
         <object width="100%" height="450" data={require("C:/Users/1607176/Documents/ajay/src/Loan/"+this.state.fileUrl)} type="application/pdf">   </object>
         {/* <object width="100%" height="450" data={require("C:\\Users\\1607176\\Documents\\ajay\\src\\files\\loan.pdf")} type="application/pdf">   </object> */}
         {/* <object width="100%" height="450" data={require(this.state.fileUrl)} type="application/pdf">   </object> */}
        </div>    
         <div className="col-sm-6"><Displayuser  formid={this.props.match.params.id}/></div>    
         </div>
        </div>
    );
   }

}
export default Checkerpage;

