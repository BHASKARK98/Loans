import React from 'react';
class Dashboard extends React.Component {
    state = {
        date: ""
      };
    
      componentDidMount() {
        this.getDate();
      }
    
      getDate = () => {
        var date = new Date().toLocaleString();
        this.setState({ date });
      };
       
    render() {    
        const { date } = this.state;    
        return (
            <div>
                <table className="table table-bordered table-hover" style={{ border: "", textAlign: "center", width: "100%",borderColor:'green' }}>
                    <p><h4 style={{color:"rgb(7, 7, 133)"}}>Welcome to Standard Chatered</h4></p><br/>
                    <p>You were logged in as : </p>
                    <p>You were logged in at :  {date}</p><br/>
                </table>
                {/* <div style={{position:relative}}>
                <Footer/>
                </div> */}
            </div>
        );
    }
}
export default Dashboard;