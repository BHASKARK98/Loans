import React from 'react';
class Display extends React.Component {
        render() {                  
        return (
            <div style={{textAlign:"center"}}> 
               TransactionId:{this.props.select.transaction} <br/>       
               CurrentStage:{this.props.select.currentstepname}<br/>
               Processdate:{this.props.select.processdate}
            </div>

        );
    }
}
export default Display;

