import React from 'react';
import customer from './customer.json';
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import './Table.css';
class Displayuser extends React.Component {
    state = {
        customers: customer,
        formid: '',
        disabled:false
    }
    user ={
       laststepname:""
}

    acceptdetails() {
        if(this.state.disabled==false){
        axios.put("http://localhost:8080/api/loans/acceptdetails/"+this.props.formid,this.user)
            .then(res => alert("Submitted for loanprocessing"))
            .catch(err => { console.log("error") })
            this.setState(
                {disabled:true}
            )
        }
    }
      
    rejectdetails() {
        if(this.state.disabled==false){
        axios.put("http://localhost:8080/api/loans/rejectdetails/"+this.props.formid,this.user)
            .then(res => alert("Rejected the form"))
            .catch(err => { console.log("error") })
            this.setState(
                {disabled:true}
            )
        }
        else{
            console.log("disabled reject");
            return this.state.disabled==true
        }
    }
    tablerow() {
        const tabrow = this.state.customers.map((customer, i) =>
            <div key={i}>
                <form style={{ backgroundColor: "white", lineHeight: "62px" }}>
                <div className="form-horizontal" className="container-fluid">
                    <div>

                        <div className="form-group" className="row" >
                            <div className="col-sm-6" >
                                <TextField label="Name" className="form-control" value={customer.username} />
                            </div>
                            <div className="col-sm-6">
                                <TextField label="Date of Birth"  className="col-sm-4" type="date" className="form-control" value={customer.dateofbirth}/>
                            </div>
                        </div >

                         <div className="form-group" className="row">
                            <div className="col-sm-6">
                                <TextField label="Mobile Number" className="form-control" value={customer.phoneno}/>
                            </div>
                            <div className="col-sm-6">
                                <TextField label="Email Id" className="form-control" value={customer.email}/>
                            </div>

                        </div>

                        <div className="form-group" className="row">
                            <div className="col-sm-6">
                                <TextField label="Account Number" className="form-control" value={customer.accountno}/>
                            </div>
                            <div className="col-sm-6">
                                <TextField label="Annual Income" className="form-control" value={customer.annualpay}/>

                            </div>
                        </div>

                        <div className="form-group" className="row">
                            <div className="col-sm-6">
                                <TextField label="Amount of loan required" className="form-control" value={customer.amountreq}/>
                            
                            </div>
                            <div className="col-sm-6">
                                <TextField label="Purpose of Loan" className="form-control" value={customer.purpose}/>
                            </div>
                        </div>
                        <div className="form-group" className="row">

                            <div className="col-sm-6" >
                                <TextField label="Profession" className="form-control" value={customer.profession}/>
                            </div>
                            <div className="col-sm-6">
                                <TextField label="country" className="form-control" value={customer.country}/>
                            </div>
                        </div>

                        <div className="form-group" className="row">
                            <div className="col-sm-6">
                                <TextField label="Nominee's name" className="form-control" value={customer.nomineename} />
                            </div>
                            <div className="form-group" className="row">
                                <div className="col-sm-6">
                                    <TextField label="Nominee's mobile Number" className="form-control" value={customer.nomineephoneno} />
                                </div>
                            </div>

                            {/* <div className="row">
                            <div className="col-sm-5"></div>
                            <div className="col-sm-1">
                            <input type="button" className="btn btn-primary" value="Apply" onClick={()=>this.adddetails()}/> </div>
                            </div> */}

                        </div>

                    </div>
                </div>
            </form>          
               </div>
        );
        return tabrow;
    }
    
   componentDidMount() {

        axios.get("http://localhost:8080/api/loans/getcustomerdetails/"+this.props.formid )
            .then(res => { this.setState({ customers: [res.data] }) })
            .catch(err => { console.log(this.props.idtosend) });
       
    }    
    render() {
        
        return (
            <div>
            <div>
                {this.tablerow()}                        
            </div>
            <div className="row">
            <div className="col-sm-4"></div>
            <div className="col-sm-1">
            <input type="button" className="btn btn-success" value="Accept" onClick={()=>this.acceptdetails()} disabled={this.state.disabled}/> </div>
            <div className="col-sm-1"></div>
            <div className="col-sm-1">
            <input type="button" className="btn btn-danger" value="Reject" onClick={()=>this.rejectdetails()}  disabled={this.state.disabled}/> </div>
            </div>
            </div>
        );
    }
}
export default Displayuser;

