import React from 'react';

class Doc extends React.Component
{
        render()
        {
                return(
                <div style={{color:"red", padding:"0%",marginTop:"0%"}}>
                        {this.props.name1}
                        {this.props.mobile1}
                        {this.props.mail1}
                        {this.props.accountno1}
                        {this.props.nominee1}
                        {this.props.nomineemobile1}
                        {this.props.amount1}
                        {this.props.purpose1}
                        {this.props.profession1}
                        {this.props.annualPay1}
                </div>

                );
        }
}
export default Doc;
