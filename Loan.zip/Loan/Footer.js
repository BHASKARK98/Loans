import React from 'react';
import './Footer.css';
import image1 from './Capture7.PNG';

class Footer extends React.Component {
    render() {
        return (
            <div className="footer">
            <div className="row">
                <div className="col-sm-5">
                    <div className=" col-sm-5 foot"><br/>
                       <img src={image1} alt="SClogo" style={{height:"50px" , width:"100%"}}/>
                    </div>
                </div>
                <div className="col-sm-7 ">
                <span><h2 className="title">Here For Good</h2></span>
                <div className="f2">
                <h8>Terms and Policies</h8> <span><h8>Help</h8></span><span><h8>Contact</h8></span><span><h8>About Us</h8></span>  
                </div>
                </div>
            </div>
            </div>

        );
    }
}
export default Footer
