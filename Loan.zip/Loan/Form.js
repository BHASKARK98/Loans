import React from 'react';
import './Form.css';
import Child from './child.js';
import axios from 'axios';
import Newnav from './Newnav';
import './sprintcssfile.css';
import TextField from '@material-ui/core/TextField';
import  {Grid}  from '@material-ui/core'; 
import Button from '@material-ui/core/Button';
class Form extends React.Component {

    state = {
        customerName:"",
        phNo:"",
        emailId:"",
        dob:"",
        accountNo:"",
        amount:"",
        purpose:"",
        profession:"",
        salary:"",
        annualPay:"",
        emergencyName:"",
        emergencyPhNo:"",
        done:"",
        aadharurl:' ',
        disabled:false
        
        
}
user ={
        username:"",
        country:"",
        phoneno:"",
        email:"",
        dateofbirth:"",
        accountno:"",
        amountreq:"",
        purpose:"",
        profession:"",
        annualpay:"",
        nomineename:"",
        nomineephoneno:"",
        aadharurl:""
}

adddetails(){
    if(this.user.username==""  || this.user.phoneno=="" || this.user.email=="" || this.user.dateofbirth=="" || this.user.accountno=="" || this.user.amountreq=="" || this.user.purpose=="" || this.user.profession=="" || this.user.annualpay==" " || this.user.nomineename=="" || this.user.nomineephoneno=="" || this.user.aadharurl==""){
        alert("Please fill all the details");
       }
       else{
        if(this.state.disabled==false){
    axios.post("http://localhost:8080/api/loans/adddetailstochecker",this.user)
    .then(res=> alert("Submitted form successfully."))
    .catch(err=>{console.log("error")})
    this.setState(
        {disabled:true}
    )
        }
}
}

    customerNameHandler(e) {
        const name = e.target.value;
        const pattern = "^[A-Za-z]+$";
        if (!name.match(pattern)) {
            this.setState({ customerName: "only alphabets" });
        }
        else{
             this.setState({customerName:""})
        this.user.username=name;
        }
    }
    customerCountryHandler(e) {
    
    this.user.country="India";
        }
    

    customerDobHandler(e) {
        const name = e.target.value;
       
        this.user.dateofbirth=name;
    
    }

    phNoHandler(e){
            const name = e.target.value;
            const pattern = "^[789][0-9]{9}$";
            if (!name.match(pattern)) {
            this.setState({ phNo: "Enter 10 digits" });
        }
        else {
            this.setState({phNo:" "})
            this.user.phoneno=name;
        }
    }

    emailIdHandler(e){
            const name = e.target.value;
            const pattern = "^[A-Za-z0-9.]+[@]+[a-zA-Z]+[.]+[a-z]+$";
            if (!name.match(pattern)) {
                this.setState({ emailId: "Enter in valid format" });
        }
        else {
            this.setState({emailId:""})
            this.user.email=name;
        }
    }


        accountNoHandler(e){
        const name = e.target.value;
        const pattern = "^[0-9]{11}$";
        if (!name.match(pattern)) {
        this.setState({ accountNo: "Enter 11 digit number" });
        }
        else{
     this.setState({accountNo:""})
     this.user.accountno=name;
        }
    }

         amountHandler(e){
          const name = e.target.value;
          const pattern = "^[0-9]+$";
            if (!name.match(pattern)) {
               this.setState({ amount: "only numbers" });
                  }
                  else {
                      this.setState({amount:""})
                      this.user.amountreq=name;
                  }
                }

         purposeHandler(e){
         const name = e.target.value;
            const pattern = "^[A-Za-z]+$";
            if (!name.match(pattern)) {
                 this.setState({ purpose: "only alphabets" });
               }
               else {
                   this.setState({purpose:""})
                   this.user.purpose=name;
                   
               }
            }

         professionHandler(e){
            const name = e.target.value;
             const pattern = "^[A-Za-z]+$";
                if (!name.match(pattern)) {
              this.setState({ profession: "only alphabets" });
                   }
                   else {
                       this.setState({profession:""})
                       this.user.profession=name;
                   }
                }

          annualPayHandler(e){
            const name = e.target.value;
            const pattern = "^[0-9]+$";
              if (!name.match(pattern)) {
                this.setState({ annualPay: "Only numbers" });
                  }
                  else {
                      this.setState({annualPay:""})
                      this.user.annualpay=name;
                  }
                }
        
            aadharHandler(e){
                const name=e.target.value;
                const name2=name.substring(12);
                const name3="C:\\Users\\1607176\\Documents\\ajay\\src\\files\\"+name2;
                this.setState({aadharurl:name3});
                this.user.aadharurl=name3;

            }
          emergencyNameHandler(e){
              const name = e.target.value;
               const pattern = "^[A-Za-z]+$";
                  if (!name.match(pattern)) {
                   this.setState({ emergencyName: "only alphabets" });
                }
                else {
                    this.setState({emergencyName:""})
                    this.user.nomineename=name;
                }
            }

           emergencyPhNoHandler(e){
                const name = e.target.value;
                const pattern = "^[789][0-9]{9}$";
                    if (!name.match(pattern)) {
                         this.setState({ emergencyPhNo: "Enter 10 digits" });
                      }
                      else{ 
                          this.setState({emergencyPhNo:""})
                          this.user.nomineephoneno=name;
                      }
                    }




    render() {
        return (
            <div>
                <div>
                    <Newnav/>
                    </div><br/>
            <div>
                     
                        <Grid container >
                <Grid item xs={4}></Grid>
              <Grid item ><div className="h2" style = {{fontFamily:"Georgia"}}>LOAN APPLICATION FORM</div></Grid> 
              </Grid>
                <form className="application" style={{paddingLeft:"10%",paddingRight:"10%"}}>

                <Grid className="heading"><span><strong>Personal Details</strong></span>
                            </Grid >
                            <br></br>

                        <Grid container spacing={3} style={{alignItems:"center"}}>
                            <Grid item xs={6} className="form-group"  >
                                <Grid item><strong> Name:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter your name" onChange={(e) => this.customerNameHandler(e)} />
                                <Child msg={this.state.customerName} />
                            </Grid>

                            <Grid item xs={6} className="form-group" >
                                <Grid><strong> Country:</strong></Grid>
                                <TextField ReadOnly style={{ width: 500 }} value="INDIA" onChange={(e) => this.customerCountryHandler(e)} />
                            </Grid>

                            <Grid item xs={6} className="form-group">
                                <Grid> <strong>Ph No:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter your phone number" onChange={(e) => this.phNoHandler(e)} />
                                <Child msg={this.state.phNo} />
                            </Grid>

                            <Grid item xs={6} className="form-group" >
                                <Grid>   <strong>E-mail ID:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter your email-id" onChange={(e) => this.emailIdHandler(e)} />
                                <Child msg={this.state.emailId} />
                            </Grid>

                            <Grid item xs={6} className="form-group" >
                                <Grid ><strong>Profession:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter your profession" onChange={(e) => this.professionHandler(e)} />
                                <Child msg={this.state.profession} />
                            </Grid>

                            <Grid item xs={6} className="form-group" >
                                <Grid ><strong>Date Of Birth:</strong></Grid>
                                <Grid  ><TextField style={{ width: 500 }} type="date" onChange={(e) => this.customerDobHandler(e)} /></Grid>
                            </Grid>
                        </Grid><br></br>

                        <Grid className="heading"><span><strong>Loan Details</strong></span></Grid><br></br>

                        <Grid container spacing={3} style={{alignItems:"center"}}>
                            <Grid item xs={6} className="form-group">
                                <Grid ><strong>Bank Account No:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter your account number" onChange={(e) => this.accountNoHandler(e)} />
                                <Child msg={this.state.accountNo} />
                            </Grid>
                            <Grid item xs={6} className="form-group" >
                                <Grid ><strong>Amount Required:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter the amount in rupees" onChange={(e) => this.amountHandler(e)} />
                                <Child msg={this.state.amount} />
                        </Grid>

                            <Grid item xs={6} className="form-group" >
                                <Grid ><strong>Purpose:</strong></Grid>
                                <TextField style={{ width: 500 }} placeholder="enter the purpose for loan" onChange={(e) => this.purposeHandler(e)} />
                                <Child msg={this.state.purpose} />
                            </Grid>
                            <Grid item  xs={6} className="form-group" >
                            <Grid ><strong>Annual Pay:</strong></Grid>
                            <TextField style={{ width: 500 }} placeholder="enter your annual pay" onChange={(e) => this.annualPayHandler(e)} />
                            <Child msg={this.state.annualPay} />
                        </Grid>
                        <Grid item xs={6} className="form-group" >
                                <Grid ><strong>AadharCard</strong></Grid>
                                {/* <TextField style={{ width: 500 }} placeholder="enter the purpose for loan" onChange={(e) => this.aadharHandler(e)} /> */}
                                {/* <Button  variant="contained"  component="label">  Upload File
                                 <input    type="file"    style={{ display: "none" }}  />
                                </Button> */}
                                <input type="file"  id="myfile"  onChange={(e) => this.aadharHandler(e)} />
                            </Grid>
                            <Grid item  xs={6} className="form-group" >
                           
                        </Grid>
                        </Grid><br></br><br></br>

                        <Grid className="heading"><span><strong>Nominee Details</strong></span></Grid><br></br>

                       <Grid container spacing={3}>
                        <Grid item  xs={6} className="form-group" >
                            <Grid ><strong>Name:</strong></Grid>
                            <TextField style={{ width: 500 }} placeholder="enter the name of the emergency contact person" onChange={(e) => this.emergencyNameHandler(e)} />
                            <Child msg={this.state.emergencyName} />
                        </Grid>

                        <Grid item xs={6} className="form-group" >
                            <Grid ><strong>Phone No:</strong></Grid>
                            <TextField style={{ width: 500 }} placeholder="enter the phone number of the emergency contact person" onChange={(e) => this.emergencyPhNoHandler(e)} />
                            <Child msg={this.state.emergencyPhNo} />
                        </Grid>
                        </Grid><br></br><br></br>

                        <Grid container spacing={2}> 
                        <Grid item xs={12} sm={5}><p></p></Grid>
                        <Grid item xs={12} sm={5}>

                        <Button variant="contained" color="primary" style={{height:"35px",width:"55px"}} onClick={() => this.adddetails()} disabled={this.state.disabled}>
                        Apply
                    </Button>
                        </Grid>
                        </Grid>
                </form>

        </div>

        </div>

                    );
                    }
            
            }
            
export default Form;