import React from 'react';
//import './sprintcssfile.css';
import Child from './child.js';
 import Nav from './Nav';
 import axios from 'axios';
 import Newnav from './Newnav';
 import Frontlog from './frontlog';
class FrontDesk extends React.Component {

  state = {
    username: "",
    email: "",
    aadharurl:"",
    loanformurl:""
  }
  user ={
    username: "",
    email: "",
    aadharurl:"",
    loanformurl:""
}
adddetails(){
  if(this.user.username=="" || this.user.email=="" || this.user.aadharurl=="" || this.user.loanformurl==""){
   alert("Please fill all the details");
  }
  else{
    axios.post("http://localhost:8080/api/loans/addfrontdeskdetails",this.user)
    .then(res=> alert("Submitted details successfully."))
    .catch(err=>{console.log("error")});
  }
}
  useridHandler(e) {
    const name = e.target.value;
    const pattern = "^[A-Za-z]+$";
    if (!name.match(pattern)) {
      this.setState({ username: "only alphabets" });
    }
 
    else{
     this.setState({ username: "" })
     this.user.username=name;
  }
}
aadharHandler(e){
  const name=e.target.value;
  const name2=name.substring(12);
  const name3="C:\\Users\\1607176\\Documents\\ajay\\src\\files\\"+name2;
  this.setState({aadharurl:name3});
  this.user.aadharurl=name3;

}
loanHandler(e){
  const name=e.target.value;
  const name2=name.substring(12);
  const name3="C:\\Users\\1607176\\Documents\\ajay\\src\\files\\"+name2;
  this.setState({loanformurl:name3});
  this.user.loanformurl=name3;

}
    emailidHandler(e) {
    const name = e.target.value;
    const pattern = "^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$";
     
    if (!name.match(pattern)) {
      this.setState({ email: "Enter in the valid format" });
    }

    else{
       this.setState({ email: "" })
       this.user.email=name;
    }
  }



  render() {
    return (
      <div >
        <div>
      <Frontlog/>
                </div>
        <h3 style={{textAlign:"center"}}><strong>Front Desk User</strong></h3>
        <form className="frontdesk">
          <div className="container-fluid" >
            <div className="form-group" >
              <div className="col-md-2">
                <p></p>
              </div>
              <div className="col-md-2">
                <strong>UserName:</strong></div>
              <div className="col-md-4">
                <input type="text" className="form-control" placeholder="enter your name" onChange={(e) => this.useridHandler(e)} required='true'/>
                <Child userid1={this.state.username} />
              </div>
              <br></br><br></br>
            </div>

            
            <div className="form-group" >
              <div className="col-md-2">
                <p></p>
              </div>
              <div className="col-md-2">
                <strong>Email ID:</strong></div>
              <div className="col-md-4">
                <input type="text" className="form-control" placeholder="enter your emailid"  onChange={(e) => this.emailidHandler(e)} required='true' />
                <Child email1={this.state.email} />
              </div>
              <br></br><br></br>
            </div>
            <div className="form-group" >
            <div className="col-md-2">
                <p></p>
              </div>
             <div className="col-md-2">
              <strong> Aadhar Card:</strong></div>
            <div className="col-md-4">             
              <input type="file"  className="form-control" id="myfile"  onChange={(e) => this.aadharHandler(e)} required='true'/>
              </div>
              
              <br></br><br></br><br/>
            </div>
            <div className="form-group" >
            <div className="col-md-2">
                <p></p>
              </div>             
              <div className="col-md-2">
              <strong>Loan form:</strong></div>
            <div className="col-md-4">        
              <input type="file"  className="form-control" id="myfile"  onChange={(e) => this.loanHandler(e)} required='true'/>
              </div>
              <br></br><br></br>
            </div>
            <div>
           
            <div className="col-md-6" >
              <button className="btn btn-primary" value="Apply" style={{width:170,marginTop:30,marginLeft:480,justifyContent:"Centre"}} onClick={()=>this.adddetails()}>Apply</button></div>
          </div>
          </div>
        </form>
      </div>
    );
  }
}
export default FrontDesk;

