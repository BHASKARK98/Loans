import React from 'react';
import Nav from './Nav';
class FrontDesk extends React.Component {
    render() {
        return (
            <div>
                <div>
                    <div>
                        <Nav/>
                        </div>
                        <div>
                
                <form>
                    <div class="form-row">
                        <div class="form-group col-md-5">
                            <label for="inputEmail4">UserID</label>
                            <input type="email" class="form-control" id="inputEmail4" placeholder="Email" />
                        </div>
                        <div class="form-group col-md-5">
                            <label for="inputPassword4">Form No</label>
                            <input type="password" class="form-control" id="inputPassword4" placeholder="Password" />
                        </div>
                    </div>
                    <div class="form-group col-md-10">
                        <label for="inputAddress">FrontDesk Name</label>
                        <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" />
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFile"/>
                            <label class="custom-file-label" for="customFile">PAN Card</label>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFile"/>
                            <label class="custom-file-label" for="customFile">Adahar Card</label>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFile"/>
                            <label class="custom-file-label" for="customFile">Passport </label>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFile"/>
                            <label class="custom-file-label" for="customFile">PayCheck </label>
                    </div>

                        <button type="submit" class="btn btn-primary col-md-8" style={{ marginleft: "50%" }}>Sign in</button>
                
                
                </form>
                </div>
                </div>
            </div>
                );
            }
        }
export default FrontDesk;
