import React from 'react';
import Doc from './Doc';
import TextField from '@material-ui/core/TextField';
import axios from 'axios';
import MaterialUIPickers from './datetimematerialui.js';
import MenuItem from '@material-ui/core/MenuItem';


import Child from './child.js';
//import Grid from 'antd/lib/card/Grid';
//import ButtonAppBar from './newnavbar.js';
import  {Grid}  from '@material-ui/core'; 
 //import Divider from '@material-ui/core/Divider';
import Button from '@material-ui/core/Button';
//import Paper from '@material-ui/core/Paper';

class Makerform extends React.Component {

    state =
        {
            name: ' ',
            mobile: ' ',
            mail: ' ',
            nominee: ' ',
            nomineeMobile: ' ',
           accountno:' ',
           amount:' ',
           purpose:' ',
           profession:' ',
           annualPay:' ',
           disabled:false
        }
    user = {
        username: "",
        country: "",
        phoneno: "",
        email: "",
        dateofbirth: "",
        accountno: "",
        amountreq: "",
        purpose: "",
        profession: "",
        annualpay: "",
        nomineename: "",
        nomineephoneno: ""
    }

    updatedetails() {
        if(this.user.username==""  || this.user.phoneno=="" || this.user.email=="" || this.user.dateofbirth=="" || this.user.accountno=="" || this.user.amountreq=="" || this.user.purpose=="" || this.user.profession=="" || this.user.annualpay==" " || this.user.nomineename=="" || this.user.nomineephoneno==""){
            alert("Please fill all the details");
           }
           else{
            if(this.state.disabled==false){
        axios.put("http://localhost:8080/api/loans/updateCustomerdetails/"+this.props.formid,this.user)
            .then(res => alert("Submitted form successfully."))
            .catch(err => { console.log("error") })
            this.setState(
                {disabled:true}
            )
           }
        }
    }

    nomineeHandler(e) {

        const nominee = e.target.value;
        const pattern = "^[a-zA-Z]+$";
        //this.setState({nominee:nominee});
        if (!nominee.match(pattern)) {
            this.setState({ nominee: "only alphabets" });

        }
        else {
            this.setState({ nominee: " " })
            this.user.nomineename = nominee;

        }
    }

    nameHandler(e) {

        const name = e.target.value;
        const pattern = "^[a-zA-Z]+$";
        //this.setState({name:name});
        if (!name.match(pattern)) {
            this.setState({ name: "only alphabets" });


        }
        else {
            this.setState({ name: " " })
            this.user.username = name;
        }
    }

    nomineemobileHandler(e) {

        const nomineeMobile = e.target.value;
        // const pattern="^[a-zA-Z]+$";
        const pattern = "^[6-9]{1}[0-9]{9}$";
        //this.setState({nomineeMobile:nomineeMobile});
        if (!nomineeMobile.match(pattern)) {
            this.setState({ nomineeMobile: "only Numbers with length of 10" });

        }
        else {
            this.setState({ nomineeMobile: " " })
            this.user.nomineephoneno = nomineeMobile;
        }
    }

    mobileHandler(e) {

        const mobile = e.target.value;
        // const pattern="^[a-zA-Z]+$";
        const pattern = "^[6-9]{1}[0-9]{9}$";
        //this.setState({mobile:mobile});
        if (!mobile.match(pattern)) {
            this.setState({ mobile: "only Numbers with length of 10" });

      }
        else {
            this.setState({ mobile: " " })
            this.user.phoneno = mobile;
        }
    }
    mailHandler(e) {

        const mail = e.target.value;
        // const pattern="^[a-zA-Z]+$";
        //const pattern="[6-9]{1}[0-9]{9}";
        const pattern = "^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$";
        //this.setState({mail:mail});
        if (!mail.match(pattern)) {
            this.setState({ mail: "Should contain @ and com/in" });

        }
        else {
            this.setState({ mail: " " })
            this.user.email = mail;
        }
    }
    customerCountryHandler(e) {
        const name = e.target.value;

        this.user.country = name;

    }

    customerDobHandler(e) {
        const name = e.target.value;

        this.user.dateofbirth = name;

    }
    accountnoHandler(e) {
        const name= e.target.value;
        const pattern = "^[0-9]{11}$";
        if (!name.match(pattern)) {
            this.setState({ accountno: "only numbers" });
        }
        else {
            this.setState({ accountno: "" })
            this.user.accountno = name;
        }
    }

    amountHandler(e) {
        const name = e.target.value;
        const pattern = "^[0-9]+$";
        if (!name.match(pattern)) {
            this.setState({ amount: "only numbers" });
        }
        else {
            this.setState({ amount: "" })
            this.user.amountreq = name;
        }
    }
    purposeHandler(e) {
        const name = e.target.value;
        const pattern = "^[A-Za-z]+$";
        if (!name.match(pattern)) {
            this.setState({ purpose: "only alphabets" });
        }
        else {
            this.setState({ purpose: "" })
            this.user.purpose = name;
        }
    }

    professionHandler(e) {
        const name = e.target.value;
        const pattern = "^[A-Za-z]+$";
        if (!name.match(pattern)) {
            this.setState({ profession: "only alphabets" });
        }
        else {
            this.setState({ profession: "" })
            this.user.profession = name;
        }
    }
    annualPayHandler(e) {
        const name = e.target.value;
        const pattern = "^[0-9]+$";
        if (!name.match(pattern)) {
            this.setState({ annualPay: "invalid" });
        }
        else {
            this.setState({ annualPay: "" })
            this.user.annualpay = name;
        }
    }

    render() {
        return (
            <div> 
            <form style={{  lineHeight: "62px" }}>

                            <div >
                            <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6"  >
                                <TextField label="Name"  onChange={(e) => this.nameHandler(e)} style={{ width: 200 }} />
                                <Doc name1={this.state.name} />
                            </div>


                            <div className="col-sm-6">
                                <TextField label="Date of Birth" defaultValue=" "  style={{ width: 200 }}  type="date"  onChange={(e) => this.customerDobHandler(e)}/>
                            </div>
            
                            </div>
                            <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6">
                                <TextField label="Mobile Number"  onChange={(e) => this.mobileHandler(e)} style={{ width: 200 }}  />
                                <Doc mobile1={this.state.mobile} />
                            </div>



                            <div className="col-sm-6">
                                <TextField label="Email Id"  onChange={(e) => this.mailHandler(e)} style={{ width: 200 }}  />
                                <Doc mail1={this.state.mail} />
                            </div>

                            </div>
                            <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6">
                                <TextField label="Account Number"  onChange={(e) => this.accountnoHandler(e)} style={{ width: 200 }}  />
                                <Doc accountno1={this.state.accountno} />
                            </div>
                    
                            
                            <div className="col-sm-6">
                                <TextField label="Annual Income"  onChange={(e) => this.annualPayHandler(e)} style={{ width: 200 }} />
                                <Doc annualPay1={this.state.annualPay} />
                            </div>
                            </div>

                        <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6">
                                <TextField label="Amount of loan required"  onChange={(e) => this.amountHandler(e)} style={{ width: 200 }}  />
                                <Doc amount1={this.state.amount} />
                            </div>
                            <div className="col-sm-6">
                                <TextField label="Purpose of Loan"  onChange={(e) => this.purposeHandler(e)} style={{ width: 200 }}  />
                                <Doc purpose1={this.state.purpose} />
                            </div>
                        
    
                            </div>
                            <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6" >
                                <TextField label="Profession"  onChange={(e) => this.professionHandler(e)} style={{ width: 200 }} />
                                <Doc profession1={this.state.profession} />
                            </div>
                            <div className="col-sm-6">
                                <TextField label="country" style={{ width: 200 }}  />
                            </div>
                
                            </div>
                            <div className="form-group" style={{display:"flex",lineHeight:"normal"}}>
                            <div className="col-sm-6">
                                <TextField label="Nominee's name" onChange={(e) => this.nomineeHandler(e)} style={{ width: 200 }}  />
                                <Doc nominee1={this.state.nominee} />
                            </div>

                                <div className="col-sm-6">
                                    <TextField label="Nominee's mobile Number" m onChange={(e) => this.nomineemobileHandler(e)} style={{ width: 200 }}  />
                                    <Doc nomineemobile1={this.state.nomineeMobile} />
                                </div>
        
                                </div>
                            <div className="col-sm-4"></div>
                            <div className="col-sm-8">
                            <button type="button" className="btn btn-primary"  style={{width:170,marginTop:20,marginLeft:10,justifyContent:"Centre"}} onClick={()=>this.updatedetails()}  disabled={this.state.disabled} >Submit</button> </div>
                    </div>
            </form>
            </div>


        );
    }
}


export default Makerform;
