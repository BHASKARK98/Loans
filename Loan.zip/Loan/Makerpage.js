import React from 'react';
import './checker.css';
import Makerform from './Makerform';
import Navops from './Navops';
import MakerLog from './makerlog';
class Makerpage extends React.Component {
    state = {
        fileUrl1: this.props.match.params.loan,
        fileUrl2: this.props.match.params.aadhar
    }

    constructor(props) {
        super(props);
        let str = this.props.match.params.loan;
        let str2 = this.props.match.params.aadhar;
        str = str.replace(/\\/g, "\\\\");
        str2 = str2.replace(/\\/g, "\\\\");
        console.log(str);
        this.state.fileUrl1 = str;
        this.state.fileurl2 = str2;
        let str1 = str.substring(49);
        let str3 = str.substring(49);
        this.state.fileUrl1 = str1;
        this.state.fileUrl2 = str3;
        console.log(str1);
    }
    render() {
        return (
            <div>
                <div>
                    <MakerLog />
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <object width="100%" height="450" data={require("C:/Users/1607176/Documents/ajay/src/Loan/" + this.state.fileUrl1)} type="application/pdf">   </object>
                    </div>
                    <div className="col-sm-6"><Makerform formid={this.props.match.params.id} /></div>
                </div>
            </div>
        );
    }

}
export default Makerpage;

