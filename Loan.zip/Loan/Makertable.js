import React from 'react';
//import customer from './customer.json';
import axios from 'axios';
import Navops from './Navops';
import './Table.css';
import {Link} from 'react-router-dom';
import MakerLog from './makerlog'
class Makertable extends React.Component {
    state = {
        users:[],
        formid: ''
    }

    componentDidMount() {
        console.log("mounted");
        axios.get("http://localhost:8080/api/loans/getmakerdetails")
            .then(res => { this.setState({ users: res.data }) })
            .catch(err => { console.log("error") });
    }
    tablerow() {

        const tabrow = this.state.users.map((user, i) =>
            <tr key={i}>
                <td><Link to={`/Makerpage/${user.loanformurl}/${user.formid}/${user.aadharurl}`}>{user.formid} </Link></td>
                <td>{user.currentstepname}</td>
                <td>{user.laststepname}</td>
                <td>{user.username}</td>
                
            </tr>

        );
        return tabrow;
    }


    getUser(e) {
        this.setState({formid: e.target.value });
    }
    getdetailsbyid() {

        axios.get("http://localhost:8080/api/loans/getcustomerdetails/" + this.state.formid)        
            .then(res => { this.setState({ users: [res.data] }) })
            .catch(err => { console.log("error") });
            if(this.state.users.formid==null){
                console.log("Enter a valid Formid")
            }

    }
    delete(){
        axios.delete("http://localhost:8080/api/loans/deletemakerdetails/"+this.state.formid)
        .then(res=>{ this.setState({ users: res.data }) } )
         .catch(err=>{console.log("Delete unsuccessful:")});
    }
    render() {
        const css = { border: "groove", textAlign: "center", backgroundColor: "rgba(135, 171, 250, 0.301)", color: "black" }
        return (
            <div>
                <div>
                    <MakerLog/>
                    </div>
                    <br/>
                <div class="input-group">
                    <input type="text" onChange={(e) => this.getUser(e)} class="form-control" placeholder="Search details based on Formid" />
                    <span class="input-group-btn">
                        <button class="btn btn-primary" onClick={() => this.getdetailsbyid()} type="button">Search</button>
                    </span>
                </div>
                <div class="input-group">
                    <input type="text" onChange={(e) => this.getUser(e)} class="form-control" placeholder="Delete details based on Formid" />
                    <span class="input-group-btn">
                        <button class="btn btn-primary" onClick={() => this.delete()}  type="button">Delete</button>
                    </span>
                </div>

                <table className="table table-bordered table-hover" style={{ border: "groove", textAlign: "center", width: "100%" }}>
                    <thead>
                        <tr >
                            <th style={css}>Formid</th>
                            <th style={css}>Curr Step Name</th>
                            <th style={css}>Last Step Name</th>
                            <th style={css}>Username</th>
                         </tr>
                    </thead>
                    <tbody>
                        {this.tablerow()}
                        
                    </tbody>
                </table>
            </div>
        );
    }
}
export default Makertable;

