import React from 'react';
import './Nav.css';
import logo from './SCB.jpg';
class Nav extends React.Component {
    render() {
        return (
            <div>
                <div>
                    <nav className="navbar navbar-default" style={{backgroundColor:"navy"}}>
                        <div className="navbar-header">
                            <a className="navbar-brand" href="#"></a>
                        </div>
                        <ul className="nav navbar-nav">
                            <li className="active"><a href="/#"><span className="glyphicon glyphicon-home"></span></a></li>
                            <li><a href="#" style={{color:"white"}}>Loans</a></li>
                            <li><a href="/Form" style={{color:"white"}}>Application Form</a></li>
                            <li><a href="/Status" style={{color:"white"}}>Status</a></li>                           
                            <li><a href="/FrontDesk" style={{color:"white"}}>Front Desk Officer</a></li>
                            <li><a href="#"><img className="img" alt="Not loaded" src={logo} /></a></li>
                        </ul>
                    </nav>
                    </div>

                <div className="line" >
                    <div className="col-xs-2 col-md-2 " style={{ backgroundColor: "rgb(22, 168, 22)", height: "10px", width: "20%" }}>
                    </div>
                    <div className="col-xs-2 col-md-2" style={{ backgroundColor: "green", height: "10px", width: "9%" }}>
                    </div>
                    <div className="col-xs-2 col-md-2" style={{ backgroundColor: "rgb(7, 7, 133)", height: "10px", width: "19%" }}>
                    </div>
                    <div className="col-xs-3 col-md-3" style={{ backgroundColor: "rgb(48, 74, 95)", height: "10px", width: "7%" }}>
                    </div>
                    <div className="col-xs-3 col-md-3" style={{ backgroundColor: "rgb(122, 110, 201)", height: "10px",  width: "45%" }}>
                    </div>
                </div><br/><br/><br/>
               
            </div>
        );
    }
}
export default Nav;