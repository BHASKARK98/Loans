import React from 'react';
class Opsdashboard extends React.Component {
    state = {
        date: ""
      };
    
      componentDidMount() {
        this.getDate();
      }
    
      getDate = () => {
        var date = new Date().toLocaleString();
        this.setState({ date });
      };
       
    render() {    
        const { date } = this.state;    
        return (
            <div>
                <table className="table table-bordered table-hover" style={{ border: "groove", textAlign: "center", width: "100%" }}>
                    <p><h4 style={{color:"rgb(7, 7, 133)"}}>Welcome to Operations Dashboard</h4></p><br/>
                    <p>You were logged in as : Ajaykumar Ch </p>
                    <p>You were logged in at :  {date}</p><br/>
                </table>
            </div>
        );
    }
}
export default Opsdashboard;