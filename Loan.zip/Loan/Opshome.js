import React from 'react';
import Dashboard from './Dashboard';
import Navops from './Navops';
class Opshome extends React.Component {
    
    render() {
        return (
            <div>
                <div>
                    <Navops />
                </div><br/><br/><br/>
                <div className="row">
                    <div className="col-sm-2"> </div>
                    <div className="col-sm-8"> <Dashboard /></div>
                    <div className="col-sm-2"> </div>
                </div>
            </div>
        );
    }
}
export default Opshome;