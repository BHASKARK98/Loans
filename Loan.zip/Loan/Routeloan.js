import React from 'react';
import Home from './Home';
import Opshome from './Opshome';
import Table from './Table';
import Checkerpage from './Checkerpage';
import Makerpage from './Makerpage';
import Form from './Form';
import Frontend from './Frontend';
import Makertable from './Makertable';
import FrontDesk from './FrontDesk';
import Status from './Status';
import NewLanding from './newlanding';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import MakerFront from './makerfront';
import CheckerFront from './checkerfront';
import MakerLog from './makerlog';
//import Frontlog from './Project/frontlog';

class RouteLoan extends React.Component{
    state={
        login:this.props.login 
    }
  render()
  {
      return(
          <div>


<BrowserRouter>
    <Switch>
      <Route exact path="/"  render={(props) => <NewLanding {...props} login={this.state.login} />} />
      <Route path="/Home" component={Home}/>
      <Route path="/Opshome" component={Opshome} />
      <Route path="/Form" component={Form} />
      <Route path="/Table" component={Table}/>
      <Route path="/Frontend" component={Frontend} />
      <Route exact path="/Checkerpage/:id/:aadhar" component={Checkerpage} />
      <Route path="/Makerpage/:loan/:id/:aadhar" component={Makerpage} />
      <Route path="/Makertable" component={Makertable} />
      <Route path="/FrontDesk" component={FrontDesk} />
      <Route path="/Status" component={Status}/>
      <Route path="/makerfront" component={MakerFront}/>
      <Route path="/checkerfront" component={CheckerFront}/>
      <Route path="/makerlog" component={MakerLog}/>
      
            </Switch>
  </BrowserRouter>
  </div>
      );
  }
    
}
export  default RouteLoan;
