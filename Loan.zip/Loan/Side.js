import React from 'react';
import customer from './customer.json';
import Display from './Display';
class Side extends React.Component {
    state = {
        customers: customer,
        user:" "
    }

    selectedCustomer(cust){
        this.setState({user:cust});
    }
    render() {
        const css={ border: "groove",textAlign: "center", backgroundColor:"rgb(7, 7, 133)",color:"white"}
        const tablerow = this.state.customers.map((customer, i) =>
                <tr  key={i} onClick={()=>this.selectedCustomer(customer)}>
                    <td>{customer.id}</td>
                    <td>{customer.transaction}</td>
                    <td>{customer.currentstepname}</td>
                    <td>{customer.laststepname}</td>
                    <td>{customer.processdate}</td>
                    <td>{customer.bookingcenter}</td>

                </tr>

            );
            
        return (
            <div>
                <Display select={this.state.user}/>
             </div>
        );
    }
}
export default Side;

