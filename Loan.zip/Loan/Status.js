import React from 'react';
import Nav from './Nav';
import customer from './customer.json';
import axios from 'axios';
import './Table.css';
import Navops from './Navops';
class Status extends React.Component {
    state = {
        customers: customer,
        formid: ''
    }
    componentDidMount() {
        console.log("mounted");
        axios.get("http://localhost:8080/api/loans/getcustomerdetails")
            .then(res => { this.setState({ customers: res.data }) })
            .catch(err => { console.log("error") });
    }
    tablerow() {

        const tabrow = this.state.customers.map((customer, i) =>
            
            <tr key={i}>
                <td><a href="/Checkerpage">{customer.formid} </a></td>
                <td>{customer.username}</td>
                <td>{customer.stepname}</td>  
                <td>{customer.status}</td>       
            </tr>
           
            
        );
        
        return tabrow;
    }
    render() {
        const css = { border: "groove", textAlign: "center", backgroundColor: "rgba(135, 171, 250, 0.301)", color: "black" }
        return (
            <div>
                   <div>
                    <Navops/>
                    </div>
                    <br/>
                <div>

                <table className="table table-bordered table-hover" style={{ border: "groove", textAlign: "center", width: "100%" }}>
                    <thead>
                        <tr >
                            <th style={css}>Formid</th>
                            <th style={css}>Username</th>
                            <th style={css}>StepName</th>
                            <th style={css}>Status</th>                           
                        </tr>
                    </thead>
                    <tbody>
                        {this.tablerow()}
                        
                    </tbody>
                </table>
                </div>
            </div>
        );
    }
}
export default Status;