import React from 'react';
//import customer from './customer.json';
import axios from 'axios';
import Navops from './Navops';
//import Footer from './Footer';
import './Table.css';
import CheckerLog from './checkrlog';
import {Link} from 'react-router-dom';
//import customer1 from './customer.json';


class Table extends React.Component {
    state = {
        customers:[],
        formid: ''
    }
    componentDidMount() {
        axios.get("http://localhost:8080/api/loans/getcheckerdetails")
            .then(res => { this.setState({ customers: res.data }) })
            .catch(err => { console.log("error") });
    }
    tablerow() {
        
        const tabrow = this.state.customers.map((customer, i) =>
            <tr key={i}>
                <td> <Link to={`/Checkerpage/${customer.formid}/${customer.aadharurl}`}>{customer.formid} </Link></td>              
                <td>{customer.currentstepname}</td>
                <td>{customer.laststepname}</td>  
                <td>{customer.username}</td>       
            </tr>
           
            
        );
        
        return tabrow;
    }
    
    
    getUser(e) {
        this.setState({ formid: e.target.value });
    }
    getdetailsbyid() {

        axios.get("http://localhost:8080/api/loans/getcustomerdetails/" + this.state.formid)
            .then(res => { this.setState({ customers: [res.data] }) })
            .catch(err => { console.log("error") });

    }
    delete(){    
        axios.delete("http://localhost:8080/api/loans/deletecheckerdetails/"+this.state.formid)
        // if(this.state.formid==(null))
        // {
        //     alert("Enter a valid formid")
        // }       
        .then(res=>{ this.setState({ customers: res.data }) } )
        .catch(err=>{console.log("Delete unsuccessful:")});
        
        
    }
    render() {
        
        const css = { border: "groove", textAlign: "center", backgroundColor: "rgba(135, 171, 250, 0.301)", color: "black" }
        return (
            <div>
                   <div>
                  <CheckerLog/>
                    </div>
                    <br/>
                <div class="input-group">
                    <input type="text" onChange={(e) => this.getUser(e)} class="form-control" placeholder="Search details based on Formid" />
                    <span class="input-group-btn">
                        <button class="btn btn-primary" onClick={() => this.getdetailsbyid()} type="button">Search</button>
                    </span>
                </div>
                
                <div class="input-group">
                    <input type="text" onChange={(e) => this.getUser(e)} class="form-control" placeholder="Delete details based on Formid" />
                    <span class="input-group-btn">
                        <button class="btn btn-primary" onClick={() => this.delete()}  type="button" style={{width:"100"}}>Delete</button>
                    </span>
                </div>

                <table className="table table-bordered table-hover" style={{ border: "groove", textAlign: "center", width: "100%" }}>
                    <thead>
                        <tr >
                            <th style={css}>Formid</th>
                            {/* <th style={css}>Transaction Ref No</th> */}
                            <th style={css}>Curr Step Name</th>
                            <th style={css}>Last Step Name</th>
                            <th style={css}>Username</th>                           
                        </tr>
                    </thead>
                    <tbody>
                        {this.tablerow()}
                        
                    </tbody>
                </table>
                
            </div>
           
        );
    }
}
export default Table;

