import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
//import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import {Link} from 'react-router-dom';
const useStyles = makeStyles(theme => ({
    root: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 0.05,
    },
  }));
    export default function CheckerLog() {
        const classes = useStyles();  
        return (
            
                <div>
                   
                                <div className={classes.root}>
      <AppBar position="static"  style={{ background: 'rgb(7, 7, 133)'}}>
        <Toolbar>
          <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
             <MenuIcon /> 
          </IconButton>
          <Typography variant="h6" className={classes.title} >
          <Link to ="" style={{color:'white',fontSize:'16px'}}>Loans</Link>
          </Typography>
          <Typography variant="h6" className={classes.title}  >
          <Link to ="/Table" style={{color:'white',fontSize:'14px'}}>Checker</Link>
          </Typography>
          {/* <Typography variant="h6" className={classes.title}>
          <a href="/Status" style={{color:'white'}}>Application Log</a>
          </Typography> */}
          <Typography variant="h6" className={classes.title} >
          <Link to ="/" style={{color:'white',fontSize:'14px'}}>Logout</Link>
          </Typography>
           {/* <Typography variant="h6" className={classes.title}>
          <a href="/FrontDesk" style={{color:'white'}}>Front Desk Officer</a>
          </Typography>  */}
          
        </Toolbar>
      </AppBar>
                </div>
               
            </div>
        );
    }

