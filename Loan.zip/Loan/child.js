import React from 'react';

class Child extends React.Component{
    render(){
        return(
            <div style={{color:"red"}}>
                {this.props.msg}
                {this.props.userid1}
                {this.props.email1}
            </div>
        );
    }
}
export default Child;