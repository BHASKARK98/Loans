import React from 'react';
import axios from 'axios';
import {Redirect,HashRouter,withRouter} from 'react-router-dom';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
//import { Link } from '@material-ui/core';
import Home from './Home';
//import FrontDesk from './FrontDesk.js'

class NewLanding extends React.Component {
    state={
        validationMessage : "",
        uservalid:"false",
        login:this.props.login,
        loginid:'',
        loginpassword:'',
        check:"",
        loginusername:'',
        projectid:''
    }

        
    componentDidMount(){
      //  e.preventDefault();
        axios.get("http://localhost:8080/api/loanlogin/validate/"+this.state.login.loanloginid+"/"+this.state.login.loanloginpassword)
        .then(res=>{
            console.log(res.data);
            if(res.data){
            this.setState({
                uservalid:"true",
        })
            ;
            
        }
        else{
            this.setState({
                uservalid:"false",
                validationMessage:"Invalid User"
            });
        }
        
        
        })
        .catch(err=>{console.log("error")});
         this.check1();
         this.multiuser();

         axios.get("http://localhost:8080/api/loanlogin/validateuser/"+this.state.login.loanloginid+"/"+this.state.login.loanloginpassword)
          .then(result=>{console.log(result.data)})

         
    }

    check1(){
        console.log(this.state.login.loanloginid);
        axios.get("http://localhost:8080/api/loanlogin/getRoleName/"+this.state.login.loanloginid)
        .then(res=>{ console.log(res.data);
            if(res.data.loginid==="Loan User"){
                
            this.setState({
                check:"Loan User",
            });
        } 

        else if(res.data.loginid==="Loan Maker"){
            this.setState({
                check:"Loan Maker",
            });
        } 
        
        else if(res.data.loginid==="Loan Checker"){
            this.setState({
                check:"Loan Checker",
            });
        }

        else if(res.data.loginid==="Loan FrontDesk"){
            this.setState({
                check:"Loan FrontDesk",
            });
        }
        this.tocomponent();
        }
       
        )
        .catch(err=>{console.log("error")});
        
       
    }

    
    multiuser(){
        axios.get("http://localhost:8080/api/loanlogin/getRolecount/"+this.state.login.loanloginid)
        .then(res=>{ 
             if(res.data){
              if(res.data.length==2)
              {
                  if((res.data[0]=="Loan Checker" && res.data[1]=="Loan Maker") || (res.data[0]=="Loan Maker" && res.data[1]=="Loan Checker"))
                  {
                      console.log('checker and maker');
                      return(this.props.history.replace("/Opshome"));
                  }
                    else if((res.data[0]=="Loan Checker" && res.data[1]=="Loan FrontDesk") || (res.data[1]=="Loan Checker" && res.data[0]=="Loan FrontDesk"))
                    {
                        console.log("checker and front desk officer");
                        return(this.props.history.replace("/checkerfront"));
                    }
                    else if((res.data[0]=="Loan Maker" && res.data[1]=="Loan FrontDesk") || (res.data[1]=="Loan Maker" && res.data[0]=="Loan FrontDesk"))
                    {
                        console.log("Maker and front desk officer");
                        return(this.props.history.replace("/makerfront"));
                    }
                }
               
             }
        })
    }
    tocomponent(){
        if(this.state.uservalid==="true" && this.state.check==="Loan Checker")
    // return <Redirect to="/Opshome"/>
        { console.log("inside the loop");
     return(this.props.history.replace("/Table"));}

         else if(this.state.uservalid==="true" && this.state.check==="Loan Maker")
         return(this.props.history.replace("/MakerTable"));

         else if(this.state.uservalid==="true" && this.state.check==="Loan User"){
            return(this.props.history.replace("/Home"));
         }

         else if(this.state.uservalid==="true" && this.state.check==="Loan FrontDesk")
         return(this.props.history.replace("/FrontDesk"));
    }



    
    render() {
        return (
          
            <div>
            </div>
         
        );
    }
     }

export default withRouter(NewLanding);
